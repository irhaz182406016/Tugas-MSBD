<!DOCTYPE html>
<html>
<head>
 <title>Mari Belajar Coding</title>
</head>
<body>
 <table border="1">
  <thead>
   <tr>
    <th>NO</th>
    <th>Nama Lengkap</th>
    <th>Jenis Kemalin</th>
    <th>Alamat</th>
   </tr>
  </thead>
  <tbody>
  <?php
   $req="http://localhost/latihan-xml/data.xml";
   $temp=file_get_contents($req);
   $xml=simplexml_load_string($temp);
    
   foreach($xml as $data)
    {
   ?>
      <tr>
       <td><?=$data->no?></td>
    <td><?=$data->namalengkap?></td>
    <td><?=$data->jeniskelamin?></td>
    <td><?=$data->alamat?></td>
   </tr>  
   <?php
    }
   ?>
  </tbody>
 </table>
</body>
</html>